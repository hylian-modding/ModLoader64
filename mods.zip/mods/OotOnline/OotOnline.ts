import * as ModLoader from '../../src/API/IModLoaderAPI'
import { EventHandler, EventsServer, EventsClient } from '../../src/API/EventHandler';
import { IOOTCore, Tunic } from '../../src/API/OOT/OOTAPI';
import { IPacketHeader, ServerNetworkHandler, ClientController, INetworkPlayer, NetworkHandler, ServerNetworkChannelHandler, NetworkChannelHandler, LobbyData, ILobbyStorage } from '../../src/API/NetworkHandler';
import { Packet } from '../../src/API/ModLoaderDefaultImpls';
import { InjectCore } from '../../src/API/CoreInjection';

interface IOotOnlineLobbyConfig {
    max_players: number
    data_syncing: boolean
    actor_syncing: boolean
}

class OotOnlineStorage{

}

class OotOnline implements ModLoader.IPlugin {

    name: string = "OotOnline"
    core_dependency: string = "OcarinaofTime"
    ModLoader!: ModLoader.IModLoaderAPI
    @InjectCore()
    core!: IOOTCore
    LobbyConfig!: IOotOnlineLobbyConfig

    constructor() {
    }

    preinit(): void {
    }

    init(): void {
    }

    postinit(): void {
        this.ModLoader.logger.info("Checking for puppet injection...")
        if (this.ModLoader.emulator.rdramRead32(0x608000) === 0x27BDFFE0) {
            this.ModLoader.logger.info("confirmed.")
        } else {
            this.ModLoader.logger.error("injection failed?")
        }
        this.ModLoader.logger.info("Checking actor table injection...")
        if (this.ModLoader.emulator.rdramRead16(0x0E8564) === 0x8060) {
            this.ModLoader.logger.info("confirmed.")
        } else {
            this.ModLoader.logger.error("injection failed?")
        }
        this.ModLoader.logger.info("Checking param injection...")
        if (this.ModLoader.emulator.rdramRead16(0x600140) === 0x0001) {
            this.ModLoader.logger.info("confirmed.")
        } else {
            this.ModLoader.logger.error("injection failed?")
        }
    }

    onTick(): void {
    }

    // You can initalize your storage here.
    @EventHandler(EventsServer.ON_LOBBY_CREATE)
    onLobbyCreation(storage: ILobbyStorage) {
        storage.data["OotOnline"] = new OotOnlineStorage()
    }

    // Once you've done this, you can access it from any packet handler like so:
    @ServerNetworkHandler("TestPacket")
    onTestPacketServer(packet: IPacketHeader) {
        var store: OotOnlineStorage = this.ModLoader.lobbyManager.getLobbyStorage(packet.lobby).data.OotOnline as OotOnlineStorage
    }

    @EventHandler(EventsClient.ON_SERVER_CONNECTION)
    onEvent(event: any): void {
        // Do something when we first connect to the server.
    }

    @EventHandler(EventsClient.CONFIGURE_LOBBY)
    onLobbySetup(lobby: LobbyData): void {
        lobby.data["OotOnline:max_players"] = 4
        lobby.data["OotOnline:data_syncing"] = true
        lobby.data["OotOnline:actor_syncing"] = true
    }

    @EventHandler(EventsClient.ON_LOBBY_JOIN)
    onJoinedLobby(lobby: LobbyData): void {
        this.LobbyConfig = lobby.data as IOotOnlineLobbyConfig
        this.ModLoader.logger.info("OotOnline settings inherited from lobby.")
    }

    // Catch this packet client side and print it.
    @NetworkHandler("TestPacket")
    onTestPacketClient(packet: IPacketHeader) {
        this.ModLoader.logger.info("Client side: " + JSON.stringify(packet));
    }

    // Catch any packets in the OotOnline channel server side and print it.
    @ServerNetworkChannelHandler("OotOnline")
    onTestPacketChannelServer(packet: IPacketHeader) {
        this.ModLoader.logger.info("Server side channel: " + JSON.stringify(packet));
    }

    // Catch any packets in the OotOnline channel client side and print it.
    @NetworkChannelHandler("OotOnline")
    onTestPacketChannelClient(packet: IPacketHeader) {
        this.ModLoader.logger.info("Client side channel: " + JSON.stringify(packet));
    }


}

module.exports = OotOnline